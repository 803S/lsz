use std::fs::File;
use std::io::Read;
use std::path::Path;

const MAX_AUTO_HASH_SIZE: u64 = 5 * 1024 * 1024; // 只对小于5MB的文件计算MD5

#[derive(Debug, Clone)]
pub struct FileSecurityInfo {
    pub mime_type: String,
    pub extension: String,
    pub is_suspicious: bool,
    pub md5_hash: Option<String>,
    pub file_signature: String,
}

fn get_file_description(mime: &str) -> String {
    match mime {
        "application/x-executable" => "Executable".to_string(),
        "application/x-mach-binary" => "Mach-O Binary".to_string(),
        "application/x-msdownload" => "Windows PE".to_string(),
        "application/x-sharedlib" => "Shared Library".to_string(),
        "application/zip" => "ZIP Archive".to_string(),
        "application/x-tar" => "TAR Archive".to_string(),
        "application/gzip" => "GZIP Compressed".to_string(),
        "application/x-bzip2" => "BZIP2 Compressed".to_string(),
        "application/x-7z-compressed" => "7-Zip Archive".to_string(),
        "application/x-rar" => "RAR Archive".to_string(),
        "image/jpeg" => "JPEG Image".to_string(),
        "image/png" => "PNG Image".to_string(),
        "image/gif" => "GIF Image".to_string(),
        "image/svg+xml" => "SVG Image".to_string(),
        "image/webp" => "WebP Image".to_string(),
        "image/bmp" => "BMP Image".to_string(),
        "image/x-icon" => "ICO Icon".to_string(),
        "text/plain" => "Plain Text".to_string(),
        "text/html" => "HTML Document".to_string(),
        "application/json" => "JSON Data".to_string(),
        "application/pdf" => "PDF Document".to_string(),
        "video/mp4" => "MP4 Video".to_string(),
        "video/x-matroska" => "MKV Video".to_string(),
        "video/x-msvideo" => "AVI Video".to_string(),
        "audio/mpeg" => "MP3 Audio".to_string(),
        "audio/wav" => "WAV Audio".to_string(),
        "audio/flac" => "FLAC Audio".to_string(),
        "application/octet-stream" => "Binary Data".to_string(),
        _ => mime.to_string(),
    }
}

pub fn analyze_file<P: AsRef<Path>>(path: P) -> std::io::Result<FileSecurityInfo> {
    let path = path.as_ref();
    let mut file = File::open(path)?;
    let metadata = file.metadata()?;

    // 对大文件跳过详细分析
    if metadata.len() > MAX_AUTO_HASH_SIZE * 2 {
        return Ok(FileSecurityInfo {
            mime_type: "application/octet-stream".to_string(),
            extension: path
                .extension()
                .and_then(|e| e.to_str())
                .unwrap_or("")
                .to_lowercase(),
            is_suspicious: false,
            md5_hash: None,
            file_signature: "Large File".to_string(),
        });
    }

    let mut buffer = vec![0u8; 8192];
    let bytes_read = file.read(&mut buffer)?;

    let info = infer::get(&buffer[..bytes_read]);
    let mime_type: String;
    let file_signature: String;

    if let Some(kind) = info {
        mime_type = kind.mime_type().to_string();
        file_signature = get_file_description(&mime_type);
    } else {
        mime_type = "application/octet-stream".to_string();
        file_signature = "Binary Data".to_string();
    };

    let extension = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();

    let safe_exts = [
        "jpg", "jpeg", "png", "gif", "bmp", "webp", "svg", "ico", "txt", "md", "pdf", "doc",
        "docx", "xls", "xlsx", "mp3", "mp4", "avi", "mkv", "mov", "wav", "flac", "zip", "rar",
        "7z", "tar", "gz", "bz2",
    ];
    let is_executable_mime = mime_type.starts_with("application/x-executable")
        || mime_type.starts_with("application/x-mach-binary")
        || mime_type.starts_with("application/x-msdownload")
        || mime_type.starts_with("application/x-elf")
        || mime_type == "application/x-sharedlib";

    let is_suspicious = safe_exts.contains(&extension.as_str()) && is_executable_mime;

    let md5_hash = if metadata.len() <= MAX_AUTO_HASH_SIZE && metadata.is_file() {
        let mut buffer = Vec::new();
        file.read_to_end(&mut buffer)?;
        Some(format!("{:x}", md5::compute(&buffer)))
    } else {
        None
    };

    Ok(FileSecurityInfo {
        mime_type,
        extension,
        is_suspicious,
        md5_hash,
        file_signature,
    })
}
