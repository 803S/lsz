use std::collections::BTreeMap;
use std::fs::File;
use std::path::Path;

const MAX_DEPTH: usize = 3;
const MAX_ENTRIES: usize = 10000;

#[derive(Debug, Clone)]
pub struct ArchiveEntry {
    pub name: String,
    pub size: String,
    pub full_path: String,
    pub is_dir: bool,
}

#[derive(Debug, Clone)]
pub struct ArchivePreview {
    pub format: String,
    pub total_files: usize,
    pub total_size: String,
    pub hidden_count: usize,
    pub grouped: BTreeMap<String, Vec<ArchiveEntry>>,
    pub is_supported: bool,
    pub truncated: bool,
}

fn format_size(size: u64) -> String {
    if size < 1024 {
        format!("{}B", size)
    } else if size < 1024 * 1024 {
        format!("{:.1}KB", size as f64 / 1024.0)
    } else if size < 1024 * 1024 * 1024 {
        format!("{:.1}MB", size as f64 / 1024.0 / 1024.0)
    } else {
        format!("{:.1}GB", size as f64 / 1024.0 / 1024.0 / 1024.0)
    }
}

fn get_depth(path: &str) -> usize {
    if path.starts_with('/') {
        path.matches('/').count() - 1
    } else {
        path.matches('/').count()
    }
}

pub fn preview_archive<P: AsRef<Path>>(path: P) -> std::io::Result<ArchivePreview> {
    let path = path.as_ref();

    // 检查文件大小，超过 100MB 则跳过详细预览
    if let Ok(meta) = path.metadata() {
        if meta.len() > 100 * 1024 * 1024 {
            return Ok(ArchivePreview {
                format: format!("Large Archive ({})", format_size(meta.len())),
                total_files: 0,
                total_size: "-".to_string(),
                hidden_count: 0,
                grouped: BTreeMap::new(),
                is_supported: true,
                truncated: true,
            });
        }
    }

    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();

    let ext_gz = if ext == "gz" || ext == "tgz" {
        Some("tar")
    } else {
        None
    };
    let ext_final = ext_gz.as_deref().unwrap_or(&ext);

    match ext_final {
        "zip" => preview_zip(path),
        "tar" => preview_tar(path),
        "gz" => preview_gzip(path),
        "7z" => preview_7z(path),
        _ => Ok(ArchivePreview {
            format: format!("{} Archive", ext.to_uppercase()),
            total_files: 0,
            total_size: "-".to_string(),
            hidden_count: 0,
            grouped: BTreeMap::new(),
            is_supported: false,
            truncated: false,
        }),
    }
}

fn build_preview(
    entries: Vec<(String, u64, bool)>,
    format: String,
    total_count: usize,
) -> ArchivePreview {
    let total_files = entries.len();
    let total_size: u64 = entries.iter().map(|(_, s, _)| s).sum();
    let hidden_count = if total_count > MAX_ENTRIES {
        total_count - MAX_ENTRIES
    } else {
        0
    };

    let entries: Vec<_> = entries.into_iter().take(MAX_ENTRIES).collect();

    let mut grouped: BTreeMap<String, Vec<ArchiveEntry>> = BTreeMap::new();

    for (full_path, size, is_dir) in entries {
        let path = Path::new(&full_path);
        let file_name = path
            .file_name()
            .map(|s| s.to_string_lossy().to_string())
            .unwrap_or_else(|| full_path.clone());

        let depth = get_depth(&full_path);
        if depth > MAX_DEPTH {
            continue;
        }

        let parent = path
            .parent()
            .map(|p| {
                let s = p.to_string_lossy().to_string();
                if s.is_empty() {
                    "/".to_string()
                } else {
                    format!("{}/", s)
                }
            })
            .unwrap_or_else(|| "/".to_string());

        let entry = ArchiveEntry {
            name: file_name,
            size: format_size(size),
            full_path,
            is_dir,
        };

        grouped.entry(parent).or_insert_with(Vec::new).push(entry);
    }

    ArchivePreview {
        format,
        total_files,
        total_size: format_size(total_size),
        hidden_count,
        grouped,
        is_supported: true,
        truncated: total_count > MAX_ENTRIES,
    }
}

fn preview_zip(path: &Path) -> std::io::Result<ArchivePreview> {
    let file = File::open(path)?;
    let mut archive = zip::ZipArchive::new(file)?;
    let mut entries = Vec::new();
    let mut total_size = 0u64;
    let total_count = archive.len();

    for i in 0..total_count {
        if entries.len() >= MAX_ENTRIES {
            break;
        }
        if let Ok(file) = archive.by_index(i) {
            let name = file.name().to_string();
            let size = if file.is_dir() { 0 } else { file.size() };
            total_size += size;
            entries.push((name, size, file.is_dir()));
        }
    }

    Ok(build_preview(
        entries,
        format!(
            "ZIP | Compressed: {} | Original: {}",
            format_size(path.metadata().map(|m| m.len()).unwrap_or(0)),
            format_size(total_size)
        ),
        total_count,
    ))
}

fn preview_tar(path: &Path) -> std::io::Result<ArchivePreview> {
    let file = File::open(path)?;
    let mut archive = tar::Archive::new(file);
    let mut entries = Vec::new();
    let mut total_count = 0;

    for entry in archive.entries()? {
        total_count += 1;
        if entries.len() >= MAX_ENTRIES {
            continue;
        }
        if let Ok(entry) = entry {
            let header = entry.header();
            let name = entry
                .path()
                .map(|p| p.to_string_lossy().to_string())
                .unwrap_or_default();
            let size = header.size().unwrap_or(0);
            let is_dir = header.entry_type().is_dir();
            entries.push((name, size, is_dir));
        }
    }

    Ok(build_preview(
        entries,
        "TAR Archive".to_string(),
        total_count,
    ))
}

fn preview_gzip(path: &Path) -> std::io::Result<ArchivePreview> {
    let file = File::open(path)?;
    let decoder = flate2::read::GzDecoder::new(file);
    let mut archive = tar::Archive::new(decoder);
    let mut entries = Vec::new();
    let mut total_count = 0;

    for entry in archive.entries()? {
        total_count += 1;
        if entries.len() >= MAX_ENTRIES {
            continue;
        }
        if let Ok(entry) = entry {
            let header = entry.header();
            let name = entry
                .path()
                .map(|p| p.to_string_lossy().to_string())
                .unwrap_or_default();
            let size = header.size().unwrap_or(0);
            let is_dir = header.entry_type().is_dir();
            entries.push((name, size, is_dir));
        }
    }

    Ok(build_preview(
        entries,
        "TAR.GZ Archive".to_string(),
        total_count,
    ))
}

fn preview_7z(path: &Path) -> std::io::Result<ArchivePreview> {
    let output = std::process::Command::new("timeout")
        .args(["10", "7z", "l", "-slt", path.to_str().unwrap_or("")])
        .output()?;

    if !output.status.success() {
        return Ok(ArchivePreview {
            format: "Large 7Z Archive (预览超时)".to_string(),
            total_files: 0,
            total_size: "-".to_string(),
            hidden_count: 0,
            grouped: BTreeMap::new(),
            is_supported: true,
            truncated: true,
        });
    }

    let stdout = String::from_utf8_lossy(&output.stdout);
    let mut entries = Vec::new();
    let mut current_name = String::new();
    let mut current_size = 0u64;
    let mut total_size = 0u64;
    let mut total_count = 0;

    for line in stdout.lines() {
        if line.starts_with("Path = ") {
            total_count += 1;
            if !current_name.is_empty() && entries.len() < MAX_ENTRIES {
                entries.push((current_name.clone(), current_size, false));
                total_size += current_size;
            }
            current_name = line.trim_start_matches("Path = ").to_string();
            current_size = 0;
        } else if line.starts_with("Size = ") {
            let size_str = line.trim_start_matches("Size = ");
            current_size = size_str.parse().unwrap_or(0);
        }
    }
    if !current_name.is_empty() && entries.len() < MAX_ENTRIES {
        entries.push((current_name, current_size, false));
        total_size += current_size;
    }

    let mut preview = build_preview(
        entries,
        format!(
            "7Z | Size: {}",
            format_size(path.metadata().map(|m| m.len()).unwrap_or(0))
        ),
        total_count,
    );
    preview.total_size = format_size(total_size);
    Ok(preview)
}
