use crossterm::event::DisableMouseCapture;
use crossterm::{
    event::{read, Event, KeyCode},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use image::GenericImageView;
use std::fs::File;
use std::io::{self, BufReader, Write};
use std::path::Path;

pub fn supports_kitty_graphics() -> bool {
    std::env::var("TERM")
        .map(|t| t.contains("kitty") || t.contains("tmux"))
        .unwrap_or(false)
}

#[derive(Debug, Clone)]
pub struct ImageInfo {
    pub width: u32,
    pub height: u32,
    pub format: String,
    pub color_type: String,
    pub exif_data: Vec<(String, String)>,
}

pub fn get_image_info<P: AsRef<Path>>(path: P) -> Option<ImageInfo> {
    let path = path.as_ref();
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();

    let format = match ext.as_str() {
        "jpg" | "jpeg" => "JPEG",
        "png" => "PNG",
        "gif" => "GIF",
        "bmp" => "BMP",
        "webp" => "WebP",
        "ico" => "ICO",
        "svg" => "SVG",
        "tiff" | "tif" => "TIFF",
        _ => "Unknown",
    }
    .to_string();

    let img = match image::open(path) {
        Ok(img) => img,
        Err(_) => return None,
    };
    let (width, height) = img.dimensions();

    let color_type = match img.color() {
        image::ColorType::L8 => "Grayscale 8-bit",
        image::ColorType::La8 => "Grayscale+Alpha 8-bit",
        image::ColorType::Rgb8 => "RGB 8-bit",
        image::ColorType::Rgba8 => "RGBA 8-bit",
        image::ColorType::L16 => "Grayscale 16-bit",
        image::ColorType::La16 => "Grayscale+Alpha 16-bit",
        image::ColorType::Rgb16 => "RGB 16-bit",
        image::ColorType::Rgba16 => "RGBA 16-bit",
        image::ColorType::Rgb32F => "RGB 32-bit Float",
        image::ColorType::Rgba32F => "RGBA 32-bit Float",
        _ => "Unknown",
    }
    .to_string();

    let exif_data = read_exif(path);

    Some(ImageInfo {
        width,
        height,
        format,
        color_type,
        exif_data,
    })
}

fn read_exif(path: &Path) -> Vec<(String, String)> {
    let file = match File::open(path) {
        Ok(f) => f,
        Err(_) => return Vec::new(),
    };

    let exif_reader = exif::Reader::new();
    let exif = match exif_reader.read_from_container(&mut BufReader::new(&file)) {
        Ok(e) => e,
        Err(_) => return Vec::new(),
    };

    let mut data = Vec::new();

    let fields = [
        (exif::Tag::Make, "Camera Make"),
        (exif::Tag::Model, "Camera Model"),
        (exif::Tag::DateTimeOriginal, "Date Taken"),
        (exif::Tag::ExposureTime, "Exposure"),
        (exif::Tag::FNumber, "Aperture"),
        (exif::Tag::ISOSpeed, "ISO"),
        (exif::Tag::FocalLength, "Focal Length"),
        (exif::Tag::GPSLatitude, "GPS Latitude"),
        (exif::Tag::GPSLongitude, "GPS Longitude"),
    ];

    for (tag, name) in fields {
        if let Some(field) = exif.get_field(tag, exif::In::PRIMARY) {
            data.push((name.to_string(), field.display_value().to_string()));
        }
    }

    data
}

pub fn is_image_file(path: &Path) -> bool {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();

    matches!(
        ext.as_str(),
        "jpg" | "jpeg" | "png" | "gif" | "bmp" | "webp" | "ico" | "tiff" | "tif"
    )
}

pub fn run_image_fullscreen<P: AsRef<Path>>(path: P) -> io::Result<()> {
    let img = match image::open(path) {
        Ok(img) => img,
        Err(e) => {
            eprintln!("无法打开图片: {}", e);
            return Ok(());
        }
    };

    let (term_width, term_height) = crossterm::terminal::size().unwrap_or((120, 40));
    let img_width = (term_width as u32).min(img.width().saturating_sub(0));
    let img_height = ((term_height as u32).saturating_sub(2) * 2).min(img.height());

    let img = img.resize_exact(img_width, img_height, image::imageops::FilterType::Lanczos3);
    let (width, height) = img.dimensions();

    enable_raw_mode()?;
    execute!(io::stdout(), EnterAlternateScreen)?;

    draw_image(&img, width, height, &mut io::stdout())?;

    loop {
        if let Ok(Event::Key(k)) = read() {
            match k.code {
                KeyCode::Char('q') | KeyCode::Char('Q') | KeyCode::Esc => break,
                _ => {}
            }
        }
    }

    disable_raw_mode()?;
    execute!(io::stdout(), LeaveAlternateScreen, DisableMouseCapture)?;
    Ok(())
}

fn draw_image(
    img: &image::DynamicImage,
    width: u32,
    height: u32,
    handle: &mut dyn Write,
) -> io::Result<()> {
    write!(handle, "\x1b[H")?;
    for y in 0..height {
        for x in 0..width {
            let top_pixel = img.get_pixel(x, y);
            let bottom_pixel = if y + 1 < height {
                img.get_pixel(x, y + 1)
            } else {
                top_pixel
            };

            let r1 = top_pixel[0];
            let g1 = top_pixel[1];
            let b1 = top_pixel[2];
            let r2 = bottom_pixel[0];
            let g2 = bottom_pixel[1];
            let b2 = bottom_pixel[2];

            let chars = get_ansi_block_chars(r1, g1, b1, r2, g2, b2);
            write!(
                handle,
                "\x1b[38;2;{};{};{}m\x1b[48;2;{};{};{}m{}",
                r1, g1, b1, r2, g2, b2, chars
            )?;
        }
        if y + 2 < height {
            write!(handle, "\x1b[0m\x1b[E")?;
        }
    }
    write!(handle, "\x1b[0m")?;
    handle.flush()?;
    Ok(())
}

fn get_ansi_block_chars(r1: u8, g1: u8, b1: u8, r2: u8, g2: u8, b2: u8) -> &'static str {
    let br1 = (r1 as u16 + g1 as u16 + b1 as u16) / 3;
    let br2 = (r2 as u16 + g2 as u16 + b2 as u16) / 3;

    if br1 < 20 && br2 < 20 {
        " "
    } else if br1 < 50 {
        "░"
    } else if br1 < 90 {
        "▒"
    } else if br1 < 140 {
        "▓"
    } else if br1 < 190 {
        "▓"
    } else {
        "█"
    }
}
