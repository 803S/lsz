use std::path::Path;
use std::process::Command;

pub struct PdfInfo {
    pub title: String,
    pub author: String,
    pub page_count: usize,
    pub file_size: u64,
}

pub fn get_pdf_info<P: AsRef<Path>>(path: P) -> Option<PdfInfo> {
    let path = path.as_ref();
    let metadata = std::fs::metadata(path).ok()?;

    let output = Command::new("pdfinfo").arg(path).output().ok()?;

    let info = String::from_utf8_lossy(&output.stdout);

    let mut title = String::new();
    let mut author = String::new();
    let mut page_count = 0;

    for line in info.lines() {
        if line.starts_with("Title:") {
            title = line.replace("Title:", "").trim().to_string();
        } else if line.starts_with("Author:") {
            author = line.replace("Author:", "").trim().to_string();
        } else if line.starts_with("Pages:") {
            if let Ok(n) = line.replace("Pages:", "").trim().parse::<usize>() {
                page_count = n;
            }
        }
    }

    Some(PdfInfo {
        title,
        author,
        page_count,
        file_size: metadata.len(),
    })
}

pub fn is_pdf_file(path: &Path) -> bool {
    path.extension()
        .and_then(|e| e.to_str())
        .map(|e| e.to_lowercase() == "pdf")
        .unwrap_or(false)
}

pub fn extract_pdf_text<P: AsRef<Path>>(path: P, max_pages: usize) -> Option<String> {
    let path = path.as_ref();

    let output = Command::new("pdftotext")
        .arg("-layout")
        .arg("-l")
        .arg(max_pages.to_string())
        .arg(path)
        .arg("-")
        .output()
        .ok()?;

    if output.status.success() {
        Some(String::from_utf8_lossy(&output.stdout).to_string())
    } else {
        let output = Command::new("pdftotext")
            .arg("-l")
            .arg(max_pages.to_string())
            .arg(path)
            .arg("-")
            .output()
            .ok()?;

        if output.status.success() {
            Some(String::from_utf8_lossy(&output.stdout).to_string())
        } else {
            None
        }
    }
}

// 用系统默认程序打开文件
pub fn open_with_default_app<P: AsRef<Path>>(path: P) -> std::io::Result<()> {
    let path = path.as_ref();

    #[cfg(target_os = "linux")]
    {
        Command::new("xdg-open").arg(path).spawn()?;
    }

    #[cfg(target_os = "macos")]
    {
        Command::new("open").arg(path).spawn()?;
    }

    #[cfg(target_os = "windows")]
    {
        Command::new("cmd")
            .args(["/C", "start", "", &path.to_string_lossy()])
            .spawn()?;
    }

    Ok(())
}

// 检查是否为媒体文件（视频/音频）
pub fn is_media_file(path: &Path) -> bool {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();

    matches!(
        ext.as_str(),
        "mp4"
            | "mkv"
            | "avi"
            | "mov"
            | "wmv"
            | "flv"
            | "webm"
            | "mp3"
            | "wav"
            | "flac"
            | "aac"
            | "ogg"
            | "m4a"
            | "pdf"
            | "doc"
            | "docx"
            | "xls"
            | "xlsx"
            | "ppt"
            | "pptx"
    )
}
